﻿namespace EducationAccelerator.Models
{
    public class FieldMappingData
    {
        public string CrmField { get; set; }
        public string SelectString { get; set; }
    }
}
